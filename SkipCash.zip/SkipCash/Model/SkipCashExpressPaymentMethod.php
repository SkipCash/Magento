<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace PaymentGateway\SkipCash\Model;

use Magento\Payment\Model\InfoInterface;

/**
 * Class SkipCashExpressPaymentMethod: model for the payment method
 */
class SkipCashExpressPaymentMethod extends \Magento\Payment\Model\Method\AbstractMethod
{

    protected $_isInitializeNeeded      = false;
    protected $redirect_uri;
    protected $_infoBlockType = \Magento\Payment\Block\Info\Cc::class;

    protected $_code = 'skipcash_express';
 	protected $_canOrder = true;
	protected $_isGateway = true;

    public function authorize(InfoInterface $payment, $amount)
    {
        parent::authorize($payment, $amount);
        return $this;
    }
    public function capture(InfoInterface $payment, $amount)
    {
        parent::capture($payment, $amount);
        return $this;
    }
    public function isAvailable(\Magento\Quote\Api\Data\CartInterface $quote = null)
    {
        if($this->_appState->getAreaCode() == 'adminhtml')return false;
        return parent::isAvailable($quote) && $this->getConfigData('active');
    }
    public function canUseForCountry($country)
    {
        /*
        for specific country, the flag will set up as 1
        */
        if ($this->getConfigData('specificcountry')) {
            $availableCountries = explode(',', $this->getConfigData('specificcountry'));
            if (!in_array($country, $availableCountries)) {
                return false;
            }
        }
        return true;
    }
}
