<?php

namespace PaymentGateway\SkipCash\Controller\Webhook;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\CsrfAwareActionInterface;
use Magento\Framework\App\Request\InvalidRequestException;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Sales\Model\Service\InvoiceService;
use Magento\Framework\DB\Transaction as TransactionDb;
use Magento\Sales\Model\OrderFactory;
use Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface;
use Magento\Sales\Api\OrderManagementInterface;
use Magento\Quote\Model\QuoteRepository;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\Message\ManagerInterface;
use PaymentGateway\SkipCash\Helper\Data;

class Index extends Action implements CsrfAwareActionInterface
{
    protected $orderFactory;
    protected $helper;
    protected $transactionDb;
    protected $cart;
    protected $transactionBuilder;
    protected $invoiceService;
    protected $messageManager;
    protected $urlBuilder;
    protected $orderManagement;
    protected $quoteRepository;
    protected $checkoutSession;
    protected $resultJsonFactory;

    public function __construct(
        Context $context,
        OrderFactory $orderFactory,
        Data $helper,
        TransactionDb $transactionDb,
        \Magento\Checkout\Model\Cart $cart,
        BuilderInterface $transactionBuilder,
        InvoiceService $invoiceService,
        OrderManagementInterface $orderManagement,
        QuoteRepository $quoteRepository,
        CheckoutSession $checkoutSession,
        ManagerInterface $messageManager,
        JsonFactory $resultJsonFactory
    ) {
        $this->orderFactory = $orderFactory;
        $this->helper = $helper;
        $this->transactionDb = $transactionDb;
        $this->invoiceService = $invoiceService;
        $this->cart = $cart;
        $this->orderManagement = $orderManagement;
        $this->quoteRepository = $quoteRepository;
        $this->checkoutSession = $checkoutSession;
        $this->transactionBuilder = $transactionBuilder;
        $this->messageManager = $messageManager;
        $this->resultJsonFactory = $resultJsonFactory;

        parent::__construct($context);
    }

    // Disable CSRF for Webhook
    public function createCsrfValidationException(
        RequestInterface $request
    ): ?InvalidRequestException {
        return null;
    }

    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }

   public function execute()
{
    $result = $this->resultJsonFactory->create();

    // Read raw JSON from SkipCash webhook
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);

    $this->helper->addLog("SkipCash Webhook JSON: " . json_encode($data));

    if (!$data || !isset($data['Custom1'])) {
        return $result->setData(['status' => '400', 'message' => 'Invalid Payload']);
    }

    // Custom1 contains Magento order increment ID
    $orderIncrementId = $data['Custom1'];
    $statusId = (int) $data['StatusId'];

    // Load order
    $order = $this->orderFactory->create()->loadByIncrementId($orderIncrementId);

    if (!$order->getId()) {
        $this->helper->addLog("Order NOT FOUND: " . $orderIncrementId);
        return $result->setData(['status' => '404']);
    }

    $this->helper->addLog("Order Found: {$orderIncrementId}, Magento Status: {$order->getStatus()}, SkipCash StatusId: {$statusId}");

    // If order already PAID, do not overwrite with failed/cancelled webhooks
    if ($order->getState() === \Magento\Sales\Model\Order::STATE_PROCESSING ||
        $order->getStatus() === "processing") 
    {
        $this->helper->addLog("Order already PAID – ignoring further updates.");
        return $result->setData(['status' => '200', 'msg' => 'Already Paid']);
    }

    switch ($statusId) {

        // 0 new, 1 pending → keep pending
        case 0:
        case 1:
            $order->setState(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT)
                  ->setStatus(\Magento\Sales\Model\Order::STATE_PENDING_PAYMENT);
            $order->save();
            $this->helper->addLog("Order marked Pending");
            break;

        // 2 = PAID → create invoice
        case 2:
            try {
                if ($order->canInvoice()) {
                    $invoice = $this->invoiceService->prepareInvoice($order);
                    $invoice->register();
 		    $invoice->setState(\Magento\Sales\Model\Order\Invoice::STATE_PAID);
                    $invoice->setSendEmail(true);
                    $transaction = $this->transactionDb->addObject($invoice)
                        ->addObject($invoice->getOrder());
                    $transaction->save();

                    $order->addStatusHistoryComment("SkipCash Payment Completed")
                          ->setState(\Magento\Sales\Model\Order::STATE_PROCESSING)
                          ->setStatus(\Magento\Sales\Model\Order::STATE_PROCESSING);
                    $order->save();

                    $this->helper->addLog("Invoice created for Order {$orderIncrementId}");
                }
            } catch (\Exception $e) {
                $this->helper->addLog("Error creating invoice: " . $e->getMessage());
            }
            break;

        // 3 cancelled, 4 failed, 5 rejected
        case 3:
        case 4:
            $order->cancel();
            $order->addStatusHistoryComment("SkipCash Updated: Failed/Cancelled");
            $order->save();
            $this->helper->addLog("Order Cancelled: {$orderIncrementId}");
            break;
        case 5:
            $order->cancel();
            $order->addStatusHistoryComment("SkipCash Updated: Failed/Cancelled");
            $order->save();
            $this->helper->addLog("Order Cancelled: {$orderIncrementId}");
            break;

        // Refund statuses
        case 6: // refunded
        case 7: // pending refund
        case 8: // refund failed
            $order->addStatusHistoryComment("SkipCash Refund Status: {$statusId}");
            $order->save();
            $this->helper->addLog("Refund Update Received");
            break;

        default:
            $this->helper->addLog("Unknown StatusId: {$statusId}");
            break;
    }

    return $result->setData(['status' => '200']);
}

}

