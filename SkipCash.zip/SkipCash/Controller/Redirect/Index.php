<?php

/**
 * Copyright ©2022 SkipCash. All rights reserved.
 */

namespace PaymentGateway\SkipCash\Controller\Redirect;

use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;

/**
 * Redirect controller
 */
class Index extends  \Magento\Framework\App\Action\Action
{
	protected $pageFactory;
	 public function __construct(Context $context,PageFactory $pageFactory) {
		$this->pageFactory = $pageFactory;

		parent::__construct($context);

    }

	public function execute()
	{
		 return $this->pageFactory->create();
	}
}
