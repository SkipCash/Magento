<?php
namespace PaymentGateway\SkipCash\Logger;

/**
 * Class Handler: handle the log file of the module
 */
class Handler extends \Magento\Framework\Logger\Handler\Base
{
    /**
     * Logging level
     * @var int
     */
    protected $loggerType = Logger::INFO;

    /**
     * File name
     * @var string
     */
    protected $fileName = '/var/log/skipcash.log';
}
