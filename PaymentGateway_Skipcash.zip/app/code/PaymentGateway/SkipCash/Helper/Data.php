<?php

namespace PaymentGateway\SkipCash\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use PaymentGateway\SkipCash\Logger\Logger;
use Magento\Framework\HTTP\Client\Curl;

class Data extends AbstractHelper
{
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;
    /**
     * @var \Magento\Framework\Encryption\EncryptorInterface
     */
    protected $encryptor;
    /**
     * @var Logger
     */
    protected $logger;
    /**
     * @var Curl
     */
    protected $curl;
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\Encryption\EncryptorInterface $encryptor,
        Logger $logger,
        Curl $curl,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
    ) {
        $this->scopeConfig = $scopeConfig;
        $this->encryptor = $encryptor;
        $this->logger = $logger;
        $this->curl = $curl;
        parent::__construct($context);
    }

    public function responseValidator($response)
    {
        switch ($response['returnCode']) {
            case 200:
                return ['status' => true, 'data' => $response['resultObj']];
            case 401:
                return ['status' => false, 'message' => 'Invalid API Key'];
            case 404:
                return ['status' => false, 'message' => $response['errorMessage']];
            case 400:
                return ['status' => false, 'message' => 'Contact the store owner'];
        }
    }
    public function getMode()
    {
        return $this->scopeConfig->getValue('payment/skipcash_express/mode', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    public function getSecretKey()
    {
        if ($this->getMode()) {
            return $this->encryptor->decrypt($this->scopeConfig->getValue('payment/skipcash_express/test_secret_key', \Magento\Store\Model\ScopeInterface::SCOPE_STORE));
        } else {
            return $this->encryptor->decrypt($this->scopeConfig->getValue('payment/skipcash_express/live_secret_key', \Magento\Store\Model\ScopeInterface::SCOPE_STORE));
        }
    }
    public function getPublicKey()
    {
        if ($this->getMode()) {
            return $this->encryptor->decrypt($this->scopeConfig->getValue('payment/skipcash_express/test_key_id', \Magento\Store\Model\ScopeInterface::SCOPE_STORE));
        } else {
            return $this->encryptor->decrypt($this->scopeConfig->getValue('payment/skipcash_express/live_key_id', \Magento\Store\Model\ScopeInterface::SCOPE_STORE));
        }
    }
    public function getClientId()
    {
        if ($this->getMode()) {
            return $this->encryptor->decrypt($this->scopeConfig->getValue('payment/skipcash_express/test_client_id', \Magento\Store\Model\ScopeInterface::SCOPE_STORE));
        } else {
            return $this->encryptor->decrypt($this->scopeConfig->getValue('payment/skipcash_express/live_client_id', \Magento\Store\Model\ScopeInterface::SCOPE_STORE));
        }
    }
    public function getApiUrl()
    {
        if ($this->getMode()) {
            return $this->scopeConfig->getValue('payment/skipcash_express/sandbox_url', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        } else {
            return $this->scopeConfig->getValue('payment/skipcash_express/production_url', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        }
    }
    public function addLog($message, $type = 'info')
    {
        if ($this->checkLogger()) {
            try {
                switch ($type) {
                    case 'info':
                        $this->logger->info(print_r($message, true));
                        break;
                    case 'error':
                        $this->logger->error(print_r($message, true));
                        break;
                    case 'debug':
                        $this->logger->debug(print_r($message, true));
                        break;
                    case 'critical':
                        $this->logger->critical(print_r($message, true));
                        break;
                    default:
                        $this->logger->info(print_r($message, true));
                        break;
                }
            } catch (\Exception $e) {
                $this->logger->error($e->getMessage());
            }
        }
    }
    public function checkLogger()
    {
        return $this->scopeConfig->getValue('payment/skipcash_express/debug', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
    public function getResponeFromSkipCash($paymentToken)
    {
        $apiUrl = $this->getApiUrl();
        $clientKey = $this->getClientId();
        $this->addLog('Check Payment Status on the SkipCash Payment Gateway');
        try {
                $this->addLog('Payment Token: ' . $paymentToken);
                $this->curl->setHeaders([
                    'Content-Type' => 'application/json',
                    'Accept' => 'application/json',
                    'Authorization' => $clientKey
                ]);
                $this->curl->setTimeout(30);
                $this->curl->get($apiUrl . '/' . $paymentToken);
                $response = $this->curl->getBody();
                $returnCode = $this->curl->getStatus();
                $response = json_decode($response, true);
                $this->addLog('Response: ' . json_encode($response));
                switch ($returnCode) {
                    case 200:
                        if ($response['resultObj']['status'] == 'paid'):
                            return $response['resultObj'];
                        else:
                            $this->addLog('Payment was not captured yet.Please try again!!');
                        endif;
                        break;
                    case 404:
                        $this->addLog('Error: ' . $response['errorMessage']);
                    default:
                }
        } catch (\Exception $e) {
            $this->addLog('Error: ' . $e->getMessage());
        }
    }
    public function getMethodPayment(){
        return $this->scopeConfig->getValue('payment/skipcash_express/action_payment', \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
    }
}
