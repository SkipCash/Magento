<?php
namespace PaymentGateway\SkipCash\Logger;

class Logger extends \Monolog\Logger
{
}
