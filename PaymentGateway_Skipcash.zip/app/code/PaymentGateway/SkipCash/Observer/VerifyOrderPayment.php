<?php

namespace PaymentGateway\SkipCash\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Checkout\Model\Session;
use Magento\Sales\Model\OrderFactory;
use PaymentGateway\SkipCash\Helper\Data;

class VerifyOrderPayment implements ObserverInterface
{
    protected $checkoutSession;
    protected $orderFactory;
    protected $helper;

    public function __construct(
        Session $checkoutSession,
        OrderFactory $orderFactory,
        Data $helper
    ) {
        $this->checkoutSession = $checkoutSession;
        $this->orderFactory = $orderFactory;
        $this->helper = $helper;
    }
    public function execute(EventObserver $observer)
    {
        $order = $this->getOrder();
        if ($order->getId()) {
            $payment = $order->getPayment();
            $method = $payment->getMethodInstance();
            $methodCode = $method->getCode();
            if ($methodCode == 'skipcash_express') {
                $this->helper->ValidateOrder($order);
            }
        }

    }
    protected function getOrder()
    {
        return $this->orderFactory->create()->load($this->checkoutSession->getLastOrderId());
    }
}
