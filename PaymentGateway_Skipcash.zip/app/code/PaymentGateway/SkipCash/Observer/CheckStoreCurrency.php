<?php
namespace PaymentGateway\SkipCash\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
/**
* Class DataAssignObserver
*/
class CheckStoreCurrency implements ObserverInterface
{
    protected $_storeManager;
    protected $_currency;
    public function __construct(
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Directory\Model\Currency $currency
    )
    {
        $this->_storeManager = $storeManager;
        $this->_currency = $currency;
    }
    public function execute(EventObserver $observer)
    {
        $support_currency = array('QAR');

        $base_currency = $this->_storeManager->getStore()->getCurrentCurrencyCode();

        if (!in_array($base_currency, $support_currency))
        {
            if($observer->getEvent()->getMethodInstance()->getCode()=="skipcash_express")
            {
                $checkResult = $observer->getEvent()->getResult();
                $checkResult->setData('is_available', false); //this is disabling the payment method at checkout page
            }
        }
        return $this;
    }
}
