<?php

/**
 * Copyright ©2022 SkipCash. All rights reserved.
 */

namespace PaymentGateway\SkipCash\Model\Adminhtml\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class TypeOfthePayment
 */
class TypeOfthePayment implements ArrayInterface
{
    const AUTH_CAPTURE = 'authorize_capture';
    const AUTHORIZE = 'authorize';

    public function toOptionArray()
    {
        return [
            /*0  */
            [
                'value' => self::AUTH_CAPTURE,
                'label' => __('Authorize and Capture (Payment)'),
            ],
            /*1  */
            [
                'value' => self::AUTHORIZE,
                'label' => __('Authorize Only'),
            ]
        ];
    }
}
