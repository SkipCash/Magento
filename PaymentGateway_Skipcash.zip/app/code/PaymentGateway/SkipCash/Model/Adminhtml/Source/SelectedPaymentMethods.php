<?php

/**
 * Copyright ©2022 SkipCash. All rights reserved.
 */

namespace PaymentGateway\SkipCash\Model\Adminhtml\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class SelectedPaymentMethods
 */
class SelectedPaymentMethods implements ArrayInterface
{
    /*0  */const PAY_METHOD_ACCOUNT = 'account';
    /*1  */const PAY_METHOD_CARD = 'card';
    /*2  */const PAY_METHOD_BANKTRANSFER = 'banktransfer';
    /*3  */const PAY_METHOD_CREDIT = 'credit';
    /**
     * Possible payment options
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            /*0  */
            [
                'value' => self::PAY_METHOD_ACCOUNT,
                'label' => 'Account',
            ],
            /*1  */
            [
                'value' => self::PAY_METHOD_CARD,
                'label' => 'Card'
            ],
            /*2  */
            [
                'value' => self::PAY_METHOD_BANKTRANSFER,
                'label' => 'Bank Transfer',
            ],
            /*3  */
            [
                'value' => self::PAY_METHOD_CREDIT,
                'label' => 'Credit',
            ]
        ];
    }
}
