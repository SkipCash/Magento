<?php

namespace PaymentGateway\SkipCash\Controller;

use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;
use Magento\Checkout\Model\Session;
use Magento\Sales\Model\OrderFactory;
use Magento\Framework\UrlInterface;
use Magento\Framework\HTTP\Client\Curl;
use Magento\Framework\Event\ManagerInterface;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Framework\Controller\Result\RedirectFactory;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Directory\Model\Currency;
use Magento\Framework\Data\Form\FormKey\Validator;
use PaymentGateway\SkipCash\Helper\Data;
use Magento\Framework\Controller\Result\JsonFactory;

abstract class Checkout extends \Magento\Framework\App\Action\Action
{
    /**
     * @var PageFactory
     */
    protected $pageFactory;
    /**
     * @var Session
     */
    protected $checkoutSession;
    /**
     * @var OrderFactory
     */
    protected $orderFactory;
    /**
     * @var UrlInterface
     */
    protected $url;
    /**
     * @var Curl
     */
    protected $curl;
    /**
     * @var ManagerInterface
     */
    protected $eventManager;
    /**
     * @var CartRepositoryInterface
     */
    protected $quoteRepository;
    /**
     * @var RedirectFactory
     */
    protected $resultRedirectFactory;
    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;
    /**
     * @var Currency
     */
    protected $currency;
    /**
     * @var Data
     */
    protected $helper;
    /**
     * @var Validator
     */
    protected $formKeyValidator;
    /**
     * @var JsonFactory
     */
    protected $jsonFactory;
    /**
     * @var \Magento\Framework\Escaper
     */
    protected $escape;
    /**
     * @var string
     */
    protected $transactionId;
    public function __construct(
        Context $context,
        PageFactory $pageFactory,
        Session $checkoutSession,
        OrderFactory $orderFactory,
        UrlInterface $url,
        Curl $curl,
        ManagerInterface $eventManager,
        CartRepositoryInterface $quoteRepository,
        RedirectFactory $resultRedirectFactory,
        StoreManagerInterface $storeManager,
        Currency $currency,
        Data $helper,
        Validator $formKeyValidator,
        JsonFactory $jsonFactory
    ) {
        parent::__construct($context);
        $this->pageFactory = $pageFactory;
        $this->checkoutSession = $checkoutSession;
        $this->orderFactory = $orderFactory;
        $this->url = $url;
        $this->curl = $curl;
        $this->eventManager = $eventManager;
        $this->quoteRepository = $quoteRepository;
        $this->resultRedirectFactory = $resultRedirectFactory;
        $this->storeManager = $storeManager;
        $this->currency = $currency;
        $this->helper = $helper;
        $this->formKeyValidator = $formKeyValidator;
        $this->jsonFactory = $jsonFactory;
        $this->escape = \Magento\Framework\App\ObjectManager::getInstance()->get('Magento\Framework\Escaper');
        $this->transactionId = null;
    }
    public function getQuote()
    {
        return $this->checkoutSession->getQuote();
    }
    public function getOrder()
    {
        return $this->orderFactory->create()->load($this->checkoutSession->getLastOrderId() ?? $this->getRequest()->getParam('orderId'));
    }
    public function errorHandler($pams)
    {
        throw new \Magento\Framework\Exception\LocalizedException(__($pams . ' is required Field. Please fill this field and try again.'));
    }
}
