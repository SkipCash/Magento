<?php

namespace PaymentGateway\SkipCash\Controller\Checkout;

use PaymentGateway\SkipCash\Controller\Checkout;

class PlaceOrderredirect extends Checkout
{
    public const STATE_PENDING_PAYMENT = 'pending_payment';
    public const STATE_PROCESSING = 'processing';
    public const STATE_PENDING = 'pending';
    public const STATE_CANCELED = 'canceled';
    public function execute()
    {
        try {
            // Get the last order
            $order = $this->getOrder();
            // Get the payment method
            $response = $this->makeRequestToGateway($order);
            return $this->jsonFactory->create()->setData($response);
        } catch (\Exception $e) {
            return $this->jsonFactory->create()->setData([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
    }
    public function makeRequestToGateway($order)
    {
        // Make a request to the payment gateway
        $payment = $order->getPayment();
        $this->transactionId = $payment->getTransactionId() ?? mt_rand(100000000, 999999999);
        $publicKey = $this->helper->getPublicKey();
        $this->helper->addLog('Public Key: '.$publicKey);
        $secretKey = $this->helper->getSecretKey();
        $this->helper->addLog('Secret Key: '.$secretKey);
        $apiUrl = $this->helper->getApiUrl();
        $this->helper->addLog('API URL: '.$apiUrl);
        $billingAddress = $order->getBillingAddress();
        $orderIncrementid = $order->getIncrementId();
        $firstName = empty($this->escape->escapeHtml($billingAddress->getFirstname())) ? $this->errorHandler('First Name') : $this->escape->escapeHtml($billingAddress->getFirstname());
        $lastName = empty($this->escape->escapeHtml($billingAddress->getLastname())) ? $this->errorHandler('Last Name') : $this->escape->escapeHtml($billingAddress->getLastname());
        $msisdn = empty($this->escape->escapeHtml($billingAddress->getTelephone())) ? $this->errorHandler('Phone Number') : $this->escape->escapeHtml($billingAddress->getTelephone());
        $email = empty($this->escape->escapeHtml($billingAddress->getEmail())) ? $this->errorHandler('Email') : $this->escape->escapeHtml($billingAddress->getEmail());
        $grandTotal = $this->escape->escapeHtml($this->getPrice($order));
        $custom1 = $this->escape->escapeHtml($orderIncrementid);
        $keyId = $publicKey;
        $Uid = $this->transactionId;
        $transactionId = $this->transactionId;
        $plainText = $this->generatePlaintext($Uid, $keyId, $grandTotal, $firstName, $lastName, $msisdn, $email, $transactionId, $custom1);
        $this->helper->addLog($plainText);
        $hash256 = $this->encode($plainText, $secretKey);
        $requestBody = '{
            "Uid":"' . $Uid . '",
            "KeyId":"' . $keyId . '",
            "Amount":"' . $grandTotal . '",
            "FirstName":"' . $firstName . '",
            "LastName":"' . $lastName . '",
            "Phone":"' . $msisdn . '",
            "Email":"' . $email . '",
            "TransactionId":"' . $transactionId . '",
            "Custom1":"' . $custom1 .
            '"}';
        $this->helper->addLog($requestBody);
        try {
            $this->curl->setHeaders([
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
                'Authorization' => $hash256
            ]);
            $this->curl->post($apiUrl, $requestBody);
            $response = $this->curl->getBody();
            $statusCode = $this->curl->getStatus();
            $responseofGateway = json_decode($response, true);
            $this->helper->addLog($responseofGateway);
            if (empty($statusCode)) {
                $this->restoreQuote($order);
                return ['success' => false, 'message' => 'Something went wrong. Please try again!!!'];
            } else {
                switch ($statusCode) {
                    case 400:
                        $this->restoreQuote($order);
                        return ['success' => false, 'message' => 'Something went wrong. Please try again!!!'];
                    case 200:
                        $order->addStatusHistoryComment('SkipCash payment order created, waiting for payment.');
                        $payment->setAdditionalInformation(['payment_token' => $responseofGateway['resultObj']['id']]);
                        $order->save();
                        $this->helper->addLog('Payment Redirection Successfully intiate.....');
                        return ['success' => true, 'payment_url' => $responseofGateway['resultObj']['payUrl']];
                    default:
                        $this->restoreQuote($order);
                        return ['success' => false, 'message' => 'Something went wrong. Please try again!!!'];
                }
            }
        } catch (\Exception $e) {
            $this->restoreQuote($order);
            $this->helper->addLog('makeRequest: '.$e->getMessage(),'error');
            return ['success' => false, 'message' => 'Something went wrong. Please try again!!!'];
        }
    }
    private function getPrice($order)
    {
        return round((float) $order->getGrandTotal(), 2);
    }
    protected function encode($plain_text, $secret_key)
    {
        $hash = hash_hmac('sha256', $plain_text, $secret_key, true);
        return base64_encode($hash);

    }

    protected function generatePlaintext($Uid, $KeyId, $Amount, $FirstName, $LastName, $Phone, $Email, $TransactionId, $Custom1)
    {
        $plainText = 'Uid=' . $Uid . ',KeyId=' . $KeyId . ',Amount=' . $Amount . ',FirstName=' . $FirstName . ',LastName=' . $LastName . ',Phone=' . $Phone . ',Email=' . $Email . ',TransactionId=' . $TransactionId . ',Custom1=' . $Custom1;
        return $plainText;
    }
    protected function restoreQuote($order)
    {
        $registry = $this->_objectManager->get('Magento\Framework\Registry');
        $orderRepo = $this->_objectManager->get('Magento\Sales\Api\OrderRepositoryInterface');
        // if get any error then we restore the current quote
        if ($order->getId() && !$order->isCanceled()) {
            $orderIncrementId = $order->getIncrementId();
            $this->checkoutSession->restoreQuote();
            $quote = $this->checkoutSession->getQuote();
            $quote->setIsActive(true);
            $this->checkoutSession->replaceQuote($quote);
            // Also we have clarify that the order is deleted if order is created
            $registry->register('isSecureArea', true);
            $orderRepo->delete($order);
            $registry->unregister('isSecureArea');
            $quote->setReservedOrderId($orderIncrementId)->save();
        }
    }
}

