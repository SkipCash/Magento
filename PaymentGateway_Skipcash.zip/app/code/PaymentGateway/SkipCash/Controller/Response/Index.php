<?php

/**
 * Copyright ©2022 SkipCash. All rights reserved.
 */

namespace PaymentGateway\SkipCash\Controller\Response;

use Magento\Sales\Model\Service\InvoiceService;
use Magento\Framework\DB\Transaction as TransactionDb;
use Magento\Framework\App\Action\Context;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\OrderFactory;
use Magento\Sales\Model\Order\Payment\Transaction\BuilderInterface;
use Magento\Sales\Model\Order\Payment\Transaction;
use Magento\Framework\Message\ManagerInterface;
use PaymentGateway\SkipCash\Helper\Data;


class Index extends \Magento\Framework\App\Action\Action
{
    protected $orderFactory;
    protected $helper;
    protected $transactionDb;
    protected $cart;
    protected $transactionBuilder;
    protected $invoiceService;
    protected $messageManager;
    protected $urlBuilder;


    public function __construct(
        Context $context,
        OrderFactory $orderFactory,
        Data $helper,
        TransactionDb $transactionDb,
        \Magento\Checkout\Model\Cart $cart,
        BuilderInterface $transactionBuilder,
        InvoiceService $invoiceService,
        ManagerInterface $messageManager

    ) {
        $this->orderFactory = $orderFactory;
        $this->helper = $helper;
        $this->transactionDb = $transactionDb;
        $this->invoiceService = $invoiceService;
        $this->cart = $cart;
        $this->urlBuilder = \Magento\Framework\App\ObjectManager::getInstance()
            ->get('Magento\Framework\UrlInterface');
        $this->transactionBuilder = $transactionBuilder;
        $this->messageManager = $messageManager;

        parent::__construct($context);
    }

    public function execute()
    {
        $this->helper->addLog('Reponse Data From the SkipCash : ' . json_encode($this->getRequest()->getParams()));
        $status = "";
        if ($this->getRequest()->getParam("status"))
            $status = ($this->getRequest()->getParam("status"));

        $transactionId = "";
        if ($this->getRequest()->getParam("transId"))
            $transactionId = ($this->getRequest()->getParam("transId"));

        $status_id = "";
        if ($this->getRequest()->getParam("statusId"))
            $status_id = ($this->getRequest()->getParam("statusId"));

        $payment_gateway_id = "";
        if ($this->getRequest()->getParam("id"))
            $payment_gateway_id = ($this->getRequest()->getParam("id"));

        $increment_order_id = "";
        if ($this->getRequest()->getParam("custom1"))
            $increment_order_id = ($this->getRequest()->getParam("custom1"));
        $order = $this->orderFactory->create()->loadByIncrementId((int) $increment_order_id);
        if ($order->getPayment() == null) {
            $this->helper->addLog("Payment is null");
            return $this->_redirect($this->urlBuilder->getBaseUrl());
        }
        if ($status == '' && $transactionId == '' && $status_id == '' && $payment_gateway_id == '' && $increment_order_id == '') {
            return $this->_redirect($this->urlBuilder->getBaseUrl());
        }
        $this->helper->addLog("Receiving payload status = $status | transaction = $transactionId | order_increment_id = $increment_order_id ");

        if ($status === "Paid" && $order) {
            if ($increment_order_id) {
                //check payment success
                $this->helper->addLog("Callback called with success");
                $skipCashData = $this->helper->getResponeFromSkipCash($payment_gateway_id) ?? [];
                try {
                    $paymentAction = $this->checkState();
                    $payment = $order->getPayment();
                    $typeOfCard = $this->getCardType(substr($skipCashData['cardNumber'], 0, 4));
                    $payment->setData('cc_type', $typeOfCard);
                    $payment->setData('cc_last_4', substr($skipCashData['cardNumber'], -4));
                    $order->setState(Order::STATE_PROCESSING)
                        ->setStatus($order->getConfig()->getStateDefaultStatus(Order::STATE_PROCESSING));
                    $formatedPrice = $order->getBaseCurrency()->formatTxt($order->getGrandTotal());
                    $transaction = $this->transactionBuilder->setPayment($payment)->setOrder($order)
                        ->setTransactionId($transactionId)
                        ->setFailSafe(true)
                        ->build($paymentAction['state']);
                    $payment->addTransactionCommentsToOrder(
                        $transaction,
                        __($paymentAction['message'], $formatedPrice)
                    );
                    $payment->addTransactionCommentsToOrder(
                        null,
                        __(
                            'SkipCash PaymentID = %1. SkipCash VisaId = %2',
                            (string) $payment_gateway_id,
                            (string) $skipCashData['visaId']
                        )
                    );
                    $payment->setAdditionalInformation(
                        [
                            Transaction::RAW_DETAILS => array("Transaction is completed."),
                            'skipcash_payment_id' => $skipCashData['id'],
                            'payUrl' => $skipCashData['payUrl'],
                        ]
                    );
                    $payment->setTransactionId($skipCashData['transactionId']);
                    $payment->setParentTransactionId(null);
                    $payment->setIsTransactionClosed(1);
                    $order->setCanSendNewEmailFlag(true);
                    $payment->save();
                    $order->save();
                    // Customer notification of order sucess.....
                    $this->prepareInvoiceForOrder($order);
                    $this->_objectManager->create('Magento\Sales\Model\OrderNotifier')->notify($order);
                    $this->helper->addLog("Payment was credited of this orderId $increment_order_id");


                    $params = array('_secure' => true, 'returnedFromSkipCash' => true, 'paymentStatus' => 'success');
                    $this->helper->addLog($this->urlBuilder->getUrl('checkout/onepage/success/', $params));
                    $this->messageManager->addSuccessMessage('Your Transaction is Successfull.');
                    return $this->_redirect($this->urlBuilder->getUrl('checkout/onepage/success/', $params));
                } catch (\Exception $e) {
                    $this->helper->addLog($e->getMessage());
                    $this->messageManager->addErrorMessage('Your Transaction is failed. Please try again!!!');
                    return $this->_redirect($this->urlBuilder->getBaseUrl());
                }
            } else {
                // no txRef or transaction ID in the request
                $this->helper->addLog("no txRef or transaction ID in the request.");
                $this->messageManager->addErrorMessage('Your Transaction is failed. Please try again!!!');
                $this->_redirect($this->urlBuilder->getBaseUrl());
            }
        } else {
            $this->redirectToCart($order);
        }
    }
    public function prepareInvoiceForOrder($order)
    {
        if ($this->helper->getMethodPayment() == 'authorize_capture') {
            $payment = $order->getPayment();
            $methodInstance = $payment ? $payment->getMethodInstance() : null;
            if ($methodInstance && $order->canInvoice()) {
                try {
                    $invoice = $this->invoiceService->prepareInvoice($order);
                    $invoice->register();
                    $invoice->getOrder()->setIsInProcess(true);
                    $invoice->setState(\Magento\Sales\Model\Order\Invoice::STATE_PAID);
                    $invoice->setSendEmail(true);
                    $transactionSave = $this->transactionDb->addObject($invoice)
                        ->addObject($invoice->getOrder());
                    $transactionSave->save();
                    $this->_objectManager->create('Magento\Sales\Model\Order\InvoiceNotifier')->notify($invoice);
                } catch (\Exception $e) {
                    $this->helper->addLog("Error in creating invoice " . $e->getMessage());
                }
            }
        }
    }
    public function redirectToCart($order)
    {
        if ($order->getId() && !$order->isCanceled()) {
            $payment = $order->getPayment();
            $order->setState(Order::STATE_CANCELED)
                ->setStatus($order->getConfig()->getStateDefaultStatus(Order::STATE_CANCELED));
            $payment->addTransactionCommentsToOrder(
                null,
                "The transaction is failed"
            );
            try {
                $items = $order->getItemsCollection();
                foreach ($items as $item)
                    $this->cart->addOrderItem($item);
                $this->cart->save();
            } catch (\Exception $e) {
                $message = $e->getMessage();
                $this->helper->addLog("Not able to add Items to cart Exception Message" . $message);
                $order->cancel();
                $payment->setParentTransactionId(null);
                $payment->save();
                $order->save();
                return $this->_redirect($this->urlBuilder->getBaseUrl());
            }
            $order->cancel();
            $payment->setParentTransactionId(null);
            $payment->save();
            $order->save();
            $this->messageManager->addErrorMessage('Your Transaction is failed. Please try again!!!');
            return $this->_redirect($this->urlBuilder->getUrl('checkout/cart', ['_secure' => true]));
        }
    }
    public function checkState()
    {
        $method = $this->helper->getMethodPayment();
        if ($method == 'authorize') {
            return ['state' => Transaction::TYPE_AUTH, 'message' => 'Authorized amount of %1.'];
        } else {
            return ['state' => Transaction::TYPE_CAPTURE, 'message' => 'We\'ve capture the amount  %1 successfully.'];
        }
    }
    public function getCardType($firstFourDigits) {
        $cardType = 'N/A';

        // Patterns for different card types
        $cardPatterns = [
            //Solo, Switch or Maestro. International safe
            'SO' => '/(^(6334)[5-9](\d{11}$|\d{13,14}$))|(^(6767)(\d{12}$|\d{14,15}$))/',
            'SM' => '/(^(5[0678])\d{11,18}$)|(^(6[^05])\d{11,18}$)|(^(601)[^1]\d{9,16}$)|(^(6011)\d{9,11}$)' .
                '|(^(6011)\d{13,16}$)|(^(65)\d{11,13}$)|(^(65)\d{15,18}$)' .
                '|(^(49030)[2-9](\d{10}$|\d{12,13}$))|(^(49033)[5-9](\d{10}$|\d{12,13}$))' .
                '|(^(49110)[1-2](\d{10}$|\d{12,13}$))|(^(49117)[4-9](\d{10}$|\d{12,13}$))' .
                '|(^(49118)[0-2](\d{10}$|\d{12,13}$))|(^(4936)(\d{12}$|\d{14,15}$))/',
            // Visa
            'VI' => '/^4[0-9]{3}/',
            // Master Card
            'MC' => '/^(5[1-5][0-9]{2}|2[2-7][0-9]{2})/',
            // American Express
            'AE' => '/^3[47][0-9]{13}$/',
            // Discover
            'DI' => '/^(6011((0|9|[2-4])[0-9]{11,14}|(74|7[7-9]|8[6-9])[0-9]{10,13})|6(4[4-9][0-9]{13,16}|' .
                '5[0-9]{14,17}))/',
            'DN' => '/^3(0[0-5][0-9]{13,16}|095[0-9]{12,15}|(6|[8-9])[0-9]{14,17})/',
            // UnionPay
            'UN' => '/^622(1(2[6-9][0-9]{10,13}|[3-9][0-9]{11,14})|[3-8][0-9]{12,15}|9([[0-1][0-9]{11,14}|' .
                '2[0-5][0-9]{10,13}))|62[4-6][0-9]{13,16}|628[2-8][0-9]{12,15}/',
            // JCB
            'JCB' => '/^35(2[8-9][0-9]{12,15}|[3-8][0-9]{13,16})/',
            'MI' => '/^(5(0|[6-9])|63|67(?!59|6770|6774))\d*$/',
            'MD' => '/^(6759(?!24|38|40|6[3-9]|70|76)|676770|676774)\d*$/',

            //Hipercard
            'HC' => '/^((606282)|(637095)|(637568)|(637599)|(637609)|(637612))\d*$/',
            //Elo
            'ELO' => '/^((509091)|(636368)|(636297)|(504175)|(438935)|(40117[8-9])|(45763[1-2])|' .
                '(457393)|(431274)|(50990[0-2])|(5099[7-9][0-9])|(50996[4-9])|(509[1-8][0-9][0-9])|' .
                '(5090(0[0-2]|0[4-9]|1[2-9]|[24589][0-9]|3[1-9]|6[0-46-9]|7[0-24-9]))|' .
                '(5067(0[0-24-8]|1[0-24-9]|2[014-9]|3[0-379]|4[0-9]|5[0-3]|6[0-5]|7[0-8]))|' .
                '(6504(0[5-9]|1[0-9]|2[0-9]|3[0-9]))|' .
                '(6504(8[5-9]|9[0-9])|6505(0[0-9]|1[0-9]|2[0-9]|3[0-8]))|' .
                '(6505(4[1-9]|5[0-9]|6[0-9]|7[0-9]|8[0-9]|9[0-8]))|' .
                '(6507(0[0-9]|1[0-8]))|(65072[0-7])|(6509(0[1-9]|1[0-9]|20))|' .
                '(6516(5[2-9]|6[0-9]|7[0-9]))|(6550(0[0-9]|1[0-9]))|' .
                '(6550(2[1-9]|3[0-9]|4[0-9]|5[0-8])))\d*$/',
            //Aura
            'AU' => '/^5078\d*$/'
        ];

        foreach ($cardPatterns as $type => $pattern) {
            if (preg_match($pattern, $firstFourDigits)) {
                $cardType = $type;
                break;
            }
        }

        return $cardType;
    }
}
