/**
 * Copyright ©2022 SkipCash. All rights reserved.
 */
/*browser:true*/
/*global define*/
define(
    [
        'uiComponent',
        'Magento_Checkout/js/model/payment/renderer-list'
    ],
    function (
        Component,
        rendererList
    ) {
        'use strict';
        rendererList.push(
            {
                type: 'skipcash_express',
                component: 'PaymentGateway_SkipCash/js/view/payment/method-renderer/skipcash_express'
            },
        );
        /** Add view logic here if needed */
        return Component.extend({});
    }
);
