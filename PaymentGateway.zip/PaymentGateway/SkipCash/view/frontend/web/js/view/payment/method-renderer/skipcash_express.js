
/*browser:true*/
/*global define*/

define(
    [
        'Magento_Checkout/js/view/payment/default',
    ],
    function (Component) {
        'use strict';

        return Component.extend({
            self: this,
            defaults: {
                template: 'PaymentGateway_SkipCash/payment/skipcash_express_form'
            },
            initialize: function () {
                this._super();
            },
            isActive: function () {
                return true;
            },
            getCode: function () {
                return 'skipcash_express';
            },
            getTitle: function()
            {
                return window.checkoutConfig.payment[this.getCode()].title;
            },
            getPlaceOrderButtonText: function()
            {
                return window.checkoutConfig.payment[this.getCode()].place_order_button_text;
            },
            getRedirectionHint: function()
            {
                return window.checkoutConfig.payment[this.getCode()].redirection_hint;
            },
        });
    }
);
