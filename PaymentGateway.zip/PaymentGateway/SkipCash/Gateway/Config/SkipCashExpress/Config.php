<?php

/**
 * Copyright ©2022 SkipCash. All rights reserved.
 */

namespace PaymentGateway\SkipCash\Gateway\Config\SkipCashExpress;

use Magento\Framework\App\Config\ScopeConfigInterface;
use PaymentGateway\SkipCash\Model\Ui\SkipCashExpress\ConfigProvider;

/**
 * Class Config: manage the configuration of the module
 */
class Config extends \Magento\Payment\Gateway\Config\Config
{
    //keys used in the configuration
    const KEY_ACTIVE = 'active';
    const KEY_TITLE = 'title';
    const KEY_JS_LIB_PRODUCTION = 'jslibproduction';
    const KEY_ID = 'key_id';
    const KEY_SECRET = 'secret_key';
    const API_URL = 'api_url';
    const KEY_SELECTED_PAYMENT_METHODS = 'selected_payment_methods';
    const KEY_PLACE_ORDER_BUTTON_TEXT = 'place_order_button_text';
    const KEY_REDIRECTION_HINT = 'redirection_hint';



    /**
     * Initialize dependencies.
     *
     * @param ScopeConfigInterface $scopeConfig
     * @param null $methodCode
     * @param string $pathPattern
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig,
        $methodCode = ConfigProvider::SkipCash_Express_Code,
        $pathPattern = self::DEFAULT_PATH_PATTERN
    ) {
        parent::__construct($scopeConfig, $methodCode, $pathPattern);
    }

    /**
     * Get Payment active status
     *
     * @return bool
     */
    public function isActive()
    {
        return (bool) $this->getValue(self::KEY_ACTIVE);
    }

    /**
     * Get title of payment
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->getValue(self::KEY_TITLE);
    }

    /**
     * Get url of js lib
     *
     * @return string
     */
    public function getJsLibProduction()
    {
        return $this->getValue(self::KEY_JS_LIB_PRODUCTION);
    }

    /**
     * Gets public key.
     *
     * @param int|null $storeId
     * @return string
     */
    public function getKeyId($storeId = null)
    {
        return $this->getValue(Config::KEY_ID, $storeId);
    }

    /**
     * Gets secret key.
     *
     * @param int|null $storeId
     * @return string
     */
    public function getSecretKey($storeId = null)
    {
        return $this->getValue(self::KEY_SECRET, $storeId);
    }

    /**
     * Gets the callback Url.
     *
     * @param int|null $storeId
     * @return string
     */
    public function getApiUrl($storeId = null)
    {
        return $this->getValue(self::API_URL, $storeId);
    }


    /**
     * Retrieve selected payment methods
     *
     * @param int|null $storeId
     * @return array
     */
    public function getSelectedPaymentMethods($storeId = null)
    {
        $selectedPaymentMethods = $this->getValue(self::KEY_SELECTED_PAYMENT_METHODS, $storeId);

        return $selectedPaymentMethods;
    }


    /**
     * Get Place Order Button Text.
     *
     * @param int|null $storeId
     * @return string
     */
    public function getPlaceOrderButtonText($storeId = null)
    {
        return $this->getValue(self::KEY_PLACE_ORDER_BUTTON_TEXT, $storeId);
    }


    /**
     * Get Redirection Hint.
     *
     * @param int|null $storeId
     * @return string
     */
    public function getRedirectionHint($storeId = null)
    {
        return $this->getValue(self::KEY_REDIRECTION_HINT, $storeId);
    }
}
