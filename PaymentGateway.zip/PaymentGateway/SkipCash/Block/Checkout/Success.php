<?php

/**
 * Copyright ©2022 SkipCash. All rights reserved.
 */

namespace PaymentGateway\SkipCash\Block\Checkout;

use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\View\Element\Template\Context;
use Magento\Checkout\Model\Session;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\OrderFactory;
use PaymentGateway\SkipCash\Logger\Logger;
use Magento\Checkout\Model\Cart;
use PaymentGateway\SkipCash\Gateway\Config\SkipCashExpress\Config;
use PaymentGateway\SkipCash\Model\Ui\SkipCashExpress\ConfigProvider;
use Magento\Framework\Message\ManagerInterface;

/**
 * Class Success: used to override success page
 */
class Success extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Sales\Model\Order $order
     */
    protected $order;

    /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;

    /**
     * @var \Magento\Checkout\Model\OrderFactory
     */
    protected $orderFactory;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\App\ObjectManager
     */
    protected $urlBuilder;

    /**
     * @var PaymentGateway\SkipCash\Logger\Logger
     */
    private $logger;

    /**
     * @var \PaymentGateway\SkipCash\Gateway\Config\SkipCashExpress\Config
     */
    protected $config;

    /**
     * @var \Magento\Framework\Locale\ResolverInterface
     */
    private $localeResolver;

    private $cart;

    //used to store the transaction ID
    protected $transID;

    public function __construct(Context $context,
        \PaymentGateway\SkipCash\Gateway\Config\SkipCashExpress\Config $config,
        Session $checkoutSession,
        OrderFactory $orderFactory,
        Logger $logger,
        \Magento\Framework\Pricing\Helper\Data $priceHelper,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Locale\ResolverInterface $localeResolver,
        Cart $cart,
        ManagerInterface $messageManager
       ) {
        $this->config = $config;
        $this->checkoutSession = $checkoutSession;
        $this->orderFactory = $orderFactory;
        $this->logger = $logger;
        $this->localeResolver = $localeResolver;

        $this->urlBuilder = \Magento\Framework\App\ObjectManager::getInstance()
                            ->get('Magento\Framework\UrlInterface');

        $this->priceHelper = $priceHelper;
        $this->storeManager = $storeManager;
        $this->cart = $cart;
        $this->messageManager = $messageManager;
        parent::__construct($context);
   }

    protected function _prepareLayout()
	{
        //if the SkipCash used as a payment method
        if($this->renderSkipCashExpress())
        {
            // get the order data
            $order = $this->getOrder();
            if ($order)
            {
                // get the billing address
                $billing = $order->getBillingAddress();
                // get the payment data of the order
                $payment = $order->getPayment();
                // generate a unique transaction id
                $this->transID = mt_rand(100000000, 999999999);
                //set the transaction id for the payment
                $payment->setTransactionId($this->transID);
                // add additional information to show that the transaction is not completed yet
                $payment->setAdditionalInformation(
                    [\Magento\Sales\Model\Order\Payment\Transaction::RAW_DETAILS => array("Transaction is not completed yet.")]
                );
                //add new transaction
                $trn = $payment->addTransaction(\Magento\Sales\Model\Order\Payment\Transaction::TYPE_CAPTURE,null,true);
                $trn->setIsClosed(0)->save();
                 $payment->addTransactionCommentsToOrder(
                    $trn,
                   "Transaction is not completed yet."
                );
                $payment->setParentTransactionId(null);
                //save the payment and order data
                $payment->save();
                $order->save();
            }
        }
    }

    //build the charge form of SkipCash
    public function getChargeForm()
    {
        // get the storeId
        $storeId = $this->getOrder()->getStoreId();
        // get the billing address to extract customer data (name, email, ..)
        $billingAddress = $this->getOrder()->getBillingAddress();
        $customerName = $this->escapeHtml($billingAddress->getFirstname() ." ". $billingAddress->getLastname());
        $customerMobile = $this->escapeHtml($billingAddress->getTelephone());
        $customerEmail = $this->escapeHtml($billingAddress->getEmail());

        //get the price of the order
        $price = $this->escapeHtml($this->getPrice());

        // get the keys from config
        $publicKey = $this->escapeHtml($this->config->getKeyId($storeId));
        $secretKey = $this->escapeHtml($this->config->getSecretKey($storeId));
        $apiUrl = $this->escapeHtml($this->config->getApiUrl($storeId));

        // set the redirectUrl for SkipCash
        $redirectUrl =  $this->urlBuilder->getBaseUrl() . "skipcash/response";
        $currency = $this->escapeHtml($this->getCurrentCurrency());
        $action = $this->getAction($publicKey, $secretKey, $apiUrl, $price);

        // set the paymentOptions for SkipCash
        $paymentOptions = $this->config->getSelectedPaymentMethods($storeId);

        $this->logger->info('Creating paymentOptions ' . json_encode($paymentOptions));

        // create the HTML form
        $chargeFormFormat =
        '<form method="GET" name="payredirect" action="%s">
            <input type="hidden" name="key_id" value="%s" />
            <input type="hidden" name="customer[email]" value="%s" />
            <input type="hidden" name="customer[phone_number]" value="%s" />
            <input type="hidden" name="customer[name]" value="%s" />
            <input type="hidden" name="tx_ref" value="%s" />
            <input type="hidden" name="amount" value="%s" />
            <input type="hidden" name="currency" value="%s" />
            <input type="hidden" name="payment_options" value="%s" />
            <input type="hidden" name="redirect_url" value="%s" />
        </form>';

        $chargeForm = sprintf($chargeFormFormat, $action, $publicKey, $customerEmail, $customerMobile, $customerName,
        $this->transID, $price, $currency, $paymentOptions, $redirectUrl);

        $this->logger->info('Creating chargeForm ' . $chargeForm);

        return $chargeForm;
    }

    //check if the SkipCash is the current payment method
    public function renderSkipCashExpress()
    {
        if ($this->getOrder()->getPayment()->getMethod() == ConfigProvider::SkipCash_Express_Code)
        {
            return true;
        }
        return false;
    }

    //get the action url of the charge form
    public function getAction($publicKey, $secretKey, $apiUrl, $price)
    {
        // get the billing address to extract customer data (name, email, ..)
        $billingAddress = $this->getOrder()->getBillingAddress();
        $firstName= $this->escapeHtml($billingAddress->getFirstname());
        $lastName= $this->escapeHtml($billingAddress->getLastname());
        $msisdn= $this->escapeHtml($billingAddress->getTelephone());;
        $email= $this->escapeHtml($billingAddress->getEmail());
        $street= $this->escapeHtml($billingAddress->getStreet()[0]);
        $city= $this->escapeHtml($billingAddress->getCity());
        if(empty($this->escapeHtml($billingAddress->getRegion()))){
            $region = 'DH';
        }
        else{
            $region = strtoupper(substr($this->escapeHtml($billingAddress->getRegion()), 0, 2));
        }
        $countryId= $this->escapeHtml($billingAddress->getCountryId());
        $postalCode= $this->escapeHtml($billingAddress->getPostcode());
        $grandTotal = $price;
        $custom1 = $this->getOrder()->getIncrementId();
        $keyId = $publicKey;
        $secretKey = $secretKey;
        $apiUrl = $apiUrl;
        $Uid = $this->transID;
        $transactionId = $this->getOrder()->getId();

        $this->logger->info('Secret Key ' . $secretKey);

        $plainText = $this->generatePlaintext($Uid,$keyId,$grandTotal,$firstName,$lastName,$msisdn,$email,$street,$city,$region,$countryId,$postalCode,$transactionId,$custom1);

        $hash256 = $this->encode($plainText,$secretKey);
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $apiUrl,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>
                '{
                    "Uid":"'.$Uid.'",
                    "KeyId":"'.$keyId.'",
                    "Amount":"'.$grandTotal.'",
                    "FirstName":"'.$firstName.'",
                    "LastName":"'.$lastName.'",
                    "Phone":"'.$msisdn.'",
                    "Email":"'.$email.'",
                    "Street":"'.$street.'",
                    "City":"'.$city.'",
                    "State":"'.$region.'",
                    "Country":"'.$countryId.'",
                    "PostalCode":"'.$postalCode.'",
                    "TransactionId":"'.$transactionId.'",
                    "Custom1":"'.$custom1.
                '"}',
            CURLOPT_HTTPHEADER => array(
                'Authorization:'.$hash256,
                'Content-Type: application/json'
            ),
        ));
        try {
            $response = curl_exec($curl);
            curl_close($curl);
            $obj = json_decode($response, true);
            if (empty($obj["returnCode"])) {
                $this->messageManager->addErrorMessage('Please check your fields. Check your field and try again!!!');
            }
            else{
                if($obj["returnCode"] == 200){
                    $payURL= $obj["resultObj"]["payUrl"];
                    return $payURL;
                }
                else {
                    $this->messageManager->addErrorMessage('Something went wrong. Please try again!!!');
                }
            }
            }
            catch (\Magento\Setup\Exception $ex){
                $this->messageManager->addErrorMessage('There was an error during transaction. Please try again!!!');

            }
    }

    //get the store language
    public function getStoreLanguage()
    {
        $locale = $this->localeResolver->getLocale();
        if ($locale) {
            $langCode = strstr($locale, '_', true);
            $langCode = str_replace("lang","",$langCode);
            $this->logger->info('CurrentStore lang ' . $langCode);
            return $langCode;
        }
        //if can not obtain the locale, used English
        return "en";
    }

    //get the Current Currency
    public function getCurrentCurrency()
    {
        return $this->storeManager->getStore()->getCurrentCurrencyCode();
    }

    //get the title that will be displayed before redirecting to SkipCash
    public function getSkipCashExpressTitle()
    {
        return __('Please wait while we directing you to SkipCash to pay %1 '. $this->getCurrentCurrency() . ' to process your order', $this->getPrice());
    }

    //get the order details
    public function getOrder()
    {
        if ($this->order == null) {
            $orderId = $this->checkoutSession->getLastOrderId();
            $this->logger->info('Creating Order for orderId $orderId');
            $this->order = $this->orderFactory->create()->load($orderId);
        }
        return $this->order;
    }

    //get the order price
    public function getPrice()
    {
        return round((float)$this->getOrder()->getGrandTotal(),2);
    }

    public function encode($plain_text, $secret_key) {
        $hash = hash_hmac('sha256', $plain_text, $secret_key, true);
        return base64_encode($hash);

    }

    public function generatePlaintext($Uid,$KeyId,$Amount,$FirstName,$LastName,$Phone,$Email,$Street,$City,$State,$Country,$PostalCode,$TransactionId,$Custom1) {
        $plainText = 'Uid='.$Uid.',KeyId='.$KeyId.',Amount='.$Amount.',FirstName='.$FirstName.',LastName='.$LastName.',Phone='.$Phone.',Email='.$Email.',Street='.$Street.',City='.$City.',State='.$State.',Country='.$Country.',PostalCode='.$PostalCode.',TransactionId='.$TransactionId.',Custom1='.$Custom1;
        return $plainText;
    }
}
