<?php

/**
 * Copyright ©2022 SkipCash. All rights reserved.
 */

namespace PaymentGateway\SkipCash\Controller\Response;

use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Action\Context;
use Magento\Checkout\Model\Session;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\OrderFactory;
use PaymentGateway\SkipCash\Logger\Logger;
use PaymentGateway\SkipCash\Gateway\Config\SkipCashExpress\Config;
use Magento\Framework\App\Response\Http;
use Magento\Sales\Model\Order\Payment\Transaction\Builder as TransactionBuilder;
use Magento\Sales\Model\Order\Payment\Transaction;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\Message\ManagerInterface;


class Index extends  \Magento\Framework\App\Action\Action
{
	protected $_objectmanager;
	protected $_checkoutSession;
	protected $_orderFactory;
	protected $urlBuilder;
	private $logger;
	protected $response;
	protected $config;
	protected $messageManager;
	protected $transactionRepository;
	protected $cart;

	public function __construct( Context $context,
			Session $checkoutSession,
			OrderFactory $orderFactory,
			Logger $logger,
			Config $config,
			 \Magento\Checkout\Model\Cart $cart,
			 \Magento\Sales\Api\TransactionRepositoryInterface $transactionRepository,
			 OrderRepositoryInterface $orderRepository,
			 \Magento\Framework\Api\SearchCriteriaBuilderFactory $searchCriteriaBuilderFactory,
             ManagerInterface $messageManager

    ) {
        $this->checkoutSession = $checkoutSession;
        $this->orderFactory = $orderFactory;
        $this->config = $config;
		$this->logger = $logger;
        $this->cart = $cart;
        $this->transactionRepository = $transactionRepository;
		$this->urlBuilder = \Magento\Framework\App\ObjectManager::getInstance()
							->get('Magento\Framework\UrlInterface');
		$this->orderRepository = $orderRepository;
		$this->searchCriteriaBuilder = $searchCriteriaBuilderFactory->create();
        $this->messageManager = $messageManager;

		parent::__construct($context);
    }

	public function execute()
	{
		$this->logger->info(json_encode($this->getRequest()->getParams()));

		$status = "";
		if($this->getRequest()->getParam("status"))
			$status = ($this->getRequest()->getParam("status"));

		$order_id = "";
		if($this->getRequest()->getParam("transId"))
			$order_id = ($this->getRequest()->getParam("transId"));

        $status_id = "";
        if($this->getRequest()->getParam("statusId"))
            $status_id = ($this->getRequest()->getParam("statusId"));

        $payment_gateway_id = "";
		if($this->getRequest()->getParam("id"))
            $payment_gateway_id = ($this->getRequest()->getParam("id"));

        $increment_order_id = "";
        if($this->getRequest()->getParam("custom1"))
            $increment_order_id = ($this->getRequest()->getParam("custom1"));

        $this->logger->info("Receiving payload status = $status | order_id = $order_id | order_increment_id = $increment_order_id ");
		if($status === "Paid")
		{
			if ($order_id)
			{
				//check payment success
				$this->logger->info("Callback called with success");

				try {
					# get transaction

					$this->searchCriteriaBuilder->addFilter('order_id', $order_id);
					$list = $this->transactionRepository->getList(
						$this->searchCriteriaBuilder->create()
					);
					$transactions = $list->getItems();
					$transaction = reset($transactions);

					if($transaction)
					{
                        $order_id = $transaction["order_id"];
						$payment_id = $transaction["payment_id"];
						$increment_id = $transaction["increment_id"];
						$this->logger->info("order_id: $order_id | payment_id: $payment_id | increment_id: $increment_id");
						# get order and payment objects
						$order = $this->orderFactory->create()->loadByIncrementId((int)$increment_order_id);

						if($order)
						{
							# get Client credentials from configurations.
							$storeId = $order->getStoreId();
                            $order->setState(Order::STATE_PROCESSING)
                            ->setStatus($order->getConfig()->getStateDefaultStatus(Order::STATE_PROCESSING));

                            $transaction->setTxnId($payment_id);
                            $transaction->setAdditionalInformation(
                                "SkipCash Transaction Id",$payment_id
                            );
                            $transaction->setAdditionalInformation(
                                "status","successful"
                            );
                            $transaction->setIsClosed(1);
                            $transaction->save();

                            # get payment data
                            $payment = $order->getPayment();
                             $payment->addTransactionCommentsToOrder(
                                $transaction,
                               "Transaction is completed successfully"
                            );

                            $payment->setParentTransactionId(null);

                            # send new email
                            $order->setCanSendNewEmailFlag(true);
                            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                            $objectManager->create('Magento\Sales\Model\OrderNotifier')->notify($order);

                            $payment->save();
                            $order->save();

                            $this->logger->info("Payment for $payment_id was credited.");


                            $params = array('_secure' => true, 'returnedFromSkipCash' => true, 'paymentStatus' => 'success');
                            $this->logger->info($this->urlBuilder->getUrl('checkout/onepage/success/', $params));
                            $this->messageManager->addSuccessMessage('Your Transaction is Successfull.');
                            $this->_redirect($this->urlBuilder->getUrl('checkout/onepage/success/', $params));
						}
						else
						{
							$this->logger->info("Order not found with order id $order_id");
                            $this->messageManager->addErrorMessage('Your Transaction is failed. Please try again!!!');
                            $this->_redirect($this->urlBuilder->getBaseUrl());
						}
					}
					else
					{
						$this->logger->info("transaction not found with transaction id $transaction");
                        $this->messageManager->addErrorMessage('Your Transaction is failed. Please try again!!!');
                        $this->_redirect($this->urlBuilder->getBaseUrl());
					}
				}
				catch(Exception $e){
					$this->logger->info($e->getMessage());
					$this->logger->info("Payment for $payment_id was not credited.");
                    $this->messageManager->addErrorMessage('Your Transaction is failed. Please try again!!!');
                    $this->_redirect($this->urlBuilder->getBaseUrl());
				}
			}
			else{
				// no txRef or transaction ID in the request
				$this->logger->info("no txRef or transaction ID in the request.");
                $this->messageManager->addErrorMessage('Your Transaction is failed. Please try again!!!');
                $this->_redirect($this->urlBuilder->getBaseUrl());
			}
		}
		else
		{
			$this->redirectToCart($order_id);
		}
	}

	public function redirectWithoutPayment()
	{
		$this->_redirect($this->urlBuilder->getUrl('checkout/onepage/success/',  ['_secure' => true]));
	}

	public function redirectToCart($order_id)
	{
		$this->searchCriteriaBuilder->addFilter('order_id', $order_id);
			$list = $this->transactionRepository->getList(
				$this->searchCriteriaBuilder->create()
			);

			$transactions = $list->getItems();
			$transaction = reset($transactions);

			if($transaction)
			{
				$order_id = $transaction["order_id"];
				$payment_id = $transaction["payment_id"];
				$increment_id = $transaction["increment_id"];
				$this->logger->info(" status === cancelled Data => order_id: $order_id | payment_id: $payment_id | increment_id: $increment_id");

				# get order and payment objects
				$order = $this->orderFactory->create()->loadByIncrementId((int)$increment_id);

				if($order)
				{
					$payment = $order->getPayment();
                    $transaction->setAdditionalInformation(
						"status","successful"
					);
					$transaction->setIsClosed(1);
					$transaction->save();
					$payment->addTransactionCommentsToOrder(
						$transaction,
						"The transaction is failed"
					);

					try{
						$items = $order->getItemsCollection();
						foreach($items as $item)
							$this->cart->addOrderItem($item);
						$this->cart->save();

					}catch(Exception $e){
						$message = $e->getMessage();
						$this->logger->info("Not able to add Items to cart Exception Message".$message);
					}
					$order->cancel();
					$payment->setParentTransactionId(null);
					$payment->save();
					$order->save();
                    $this->messageManager->addErrorMessage('Your Transaction is failed. Please try again!!!');
					$this->_redirect($this->urlBuilder->getUrl('checkout/cart',  ['_secure' => true]));
				}
			}
			else
			{
                $this->messageManager->addErrorMessage('Your Transaction is failed. Please try again!!!');
				$this->_redirect($this->urlBuilder->getUrl('checkout/onepage/success/',  ['_secure' => true]));
			}
	}
}
