<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace PaymentGateway\SkipCash\Model;

/**
 * Class SkipCashExpressPaymentMethod: model for the payment method
 */
class SkipCashExpressPaymentMethod extends \Magento\Payment\Model\Method\AbstractMethod
{

	protected $_isInitializeNeeded      = false;
    protected $redirect_uri;
    protected $_code = 'skipcash_express';
 	protected $_canOrder = true;
	protected $_isGateway = true;

}
