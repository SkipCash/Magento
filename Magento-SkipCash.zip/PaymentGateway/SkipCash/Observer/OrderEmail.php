<?php
/**
* Copyright © 2016 Magento. All rights reserved.
* See COPYING.txt for license details.
*/
namespace PaymentGateway\SkipCash\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use \Magento\Checkout\Model\Session as CheckoutSession;
/**
* Class DataAssignObserver
*/
class OrderEmail implements ObserverInterface
{
    protected $checkoutSession;
    public function __construct(
        CheckoutSession $checkoutSession
    ) {
        $this->checkoutSession = $checkoutSession;
    }
    public function execute(EventObserver $observer)
    {
        $order = $observer->getOrder();
        $quote=$this->checkoutSession->getQuote();
        $paymentCode =$order && $order->getPayment() && $order->getPayment()->getMethodInstance() ? $order->getPayment()->getMethodInstance()->getCode():'';
        if($paymentCode =="skipcash_express")
        {
            $order->setCanSendNewEmailFlag(false);
        }
        return $this;
    }
}
