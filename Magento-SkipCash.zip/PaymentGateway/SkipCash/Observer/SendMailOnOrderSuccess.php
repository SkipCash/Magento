<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace PaymentGateway\SkipCash\Observer;

use Magento\Framework\Event\ObserverInterface;

/**
 * Class DataAssignObserver
 */
class SendMailOnOrderSuccess implements ObserverInterface
{

    protected $orderSender;
    protected $orderFactory;

    public function __construct(
        \Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender,
        \Magento\Sales\Model\OrderFactory $orderFactory
    ) {
        $this->orderSender = $orderSender;
        $this->orderFactory = $orderFactory;
    }
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $orderIds = $observer->getEvent()->getOrderIds();
        $orderId = current($orderIds);
        $order = $this->orderFactory->create()->load($orderId);
        if ($order && $order->getId()) {
            $payment = $order->getPayment();
            $methodCode = $payment ? $payment->getMethod() : '';
            if ($methodCode == 'skipcash_express') {
                $this->sendOrderNotification($order);
            }
        }
        return;
    }
    protected function sendOrderNotification($order)
    {
        if (!$order->getEmailSent()) {
            try {
                $this->orderSender->send($order);
                $order->addStatusHistoryComment(
                    __('Notified customer about order #%1.', $order->getIncrementId())
                )->setIsCustomerNotified(
                        true
                    )->save();
            } catch (\Exception $e) {

            }
        }
    }
}
