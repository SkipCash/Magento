<?php
/**
 * Copyright ©2022 SkipCash. All rights reserved.
 */

\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'PaymentGateway_SkipCash',
    __DIR__
);
