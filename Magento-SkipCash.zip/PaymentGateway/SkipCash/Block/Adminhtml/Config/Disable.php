<?php

/**
 * Copyright © 2022 SkipCash. All rights reserved.
 */

namespace PaymentGateway\SkipCash\Block\Adminhtml\Config;

use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Config\Block\System\Config\Form\Field;

/**
 * Class Disable: used to disable the Webhook URL in the admin
 */
class Disable extends Field
{
    protected function _getElementHtml(AbstractElement $element)
    {
        $element->setDisabled('disabled');
        return $element->getElementHtml();
    }
}
