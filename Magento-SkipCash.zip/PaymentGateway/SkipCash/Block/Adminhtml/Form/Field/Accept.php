<?php


namespace PaymentGateway\SkipCash\Block\Adminhtml\Form\Field;

use Magento\Config\Block\System\Config\Form\Field as ConfigField;
use Magento\Framework\Data\Form\Element\AbstractElement;
use Magento\Framework\UrlInterface;

/**
 * Class Accept
 * @package Meetanshi\QBMSPayment\Block\Adminhtml\Form\Field
 */
class Accept extends ConfigField
{
    /**
     * @param AbstractElement $element
     * @return string
     */
    protected function _renderValue(AbstractElement $element)
    {
        $stores = $this->_storeManager->getStores();
        $data = '';
        $url = [];

        foreach ($stores as $store) {
            $baseUrl = $store->getBaseUrl(UrlInterface::URL_TYPE_WEB, true);
            if ($baseUrl) {
                $value = $baseUrl . 'skipcash/response/index';
                $url[] = "<div>" . $value . "</div>";
            }
        }

        $url = array_unique($url);
        foreach ($url as $webUrl) {
            $data .= "<div style='color: red;'>" . $webUrl . "</div>";
        }
        if($element->getFieldConfig('comment')){
            $data .= "<p class='note'><span>" . $element->getFieldConfig('comment') . "</span></p>";
        }
        return '<td class="value">' . $data . '</td>';
    }

    /**
     * @param AbstractElement $element
     * @return string
     */
    protected function _renderInheritCheckbox(AbstractElement $element)
    {
        return '<td class="use-default"></td>';
    }
}
