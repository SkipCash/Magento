# Magento 2 skipcash payment gateway

## Installation

1 - Copy the content of the zip file into Magento directory/app/code folder

2 - Open a terminal and run the following command in your Magento directory:

```bash
php bin/magento setup:upgrade
php bin/magento cache:flush
php bin/magento cache:clean
```



3 - If you run Magento in production mode, you also must compile and deploy the module’s static files:

```bash
php bin/magento setup:di:compile
php bin/magento setup:static-content:deploy
```

4 - For more information, please check the documentation shipped with the item
