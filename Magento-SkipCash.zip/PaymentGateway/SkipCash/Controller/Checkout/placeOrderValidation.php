<?php

namespace PaymentGateway\SkipCash\Controller\Checkout;


use PaymentGateway\SkipCash\Controller\Checkout;



class PlaceOrderValidation extends Checkout
{

    public function execute()
    {
        try {
            if (!$this->formKeyValidator->validate($this->getRequest())) {
                return $this->jsonFactory->create()->setData([
                    'success' => false,
                    'message' => 'Payment Error'
                ]);
            }
        } catch (\Exception $e) {
            return $this->jsonFactory->create()->setData([
                'success' => false,
                'message' => $e->getMessage()
            ]);
        }
        $this->helper->addLog('Form Key Validation Successful');
        return $this->jsonFactory->create()->setData([
            'success' => true,
            'message' => 'Validation Successful'
        ]);
    }

}
