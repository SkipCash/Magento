<?php

/**
 * Copyright ©2022 SkipCash. All rights reserved.
 */

namespace PaymentGateway\SkipCash\Model\Adminhtml\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class AllowedPaymentMethods
 */
class AllowedPaymentMethods implements ArrayInterface
{
    /**
     * Possible selection options for payment types
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => 0,
                'label' => 'All payment methods',
            ],
            [
                'value' => 1,
                'label' => 'Select methods'
            ],
        ];
    }
}
