<?php

/**
 * Copyright ©2022 SkipCash. All rights reserved.
 */

namespace PaymentGateway\SkipCash\Model\Adminhtml\Source;

use Magento\Framework\Option\ArrayInterface;

/**
 * Class EnvironmentMode
 */
class EnvironmentMode implements ArrayInterface
{
    const SANDBOX = 1;
    const PRODUCTION = 0;

    public function toOptionArray()
    {
        return [
            /*0  */
            [
                'value' => self::SANDBOX,
                'label' => __('Sandbox'),
            ],
            /*1  */
            [
                'value' => self::PRODUCTION,
                'label' => __('Production'),
            ]
        ];
    }
}
