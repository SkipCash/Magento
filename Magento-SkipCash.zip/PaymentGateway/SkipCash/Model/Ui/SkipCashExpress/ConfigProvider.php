<?php

/**
 * Copyright ©2022 SkipCash. All rights reserved.
 */

namespace PaymentGateway\SkipCash\Model\Ui\SkipCashExpress;

use PaymentGateway\SkipCash\Gateway\Config\SkipCashExpress\Config;
use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Session\SessionManagerInterface;

/**
 * Class ConfigProvider
 */
class ConfigProvider implements ConfigProviderInterface
{
    const SkipCash_Express_Code = 'skipcash_express';


    /**
     * @var Config
     */
    private $config;

    /**
     * @var SessionManagerInterface
     */
    private $session;


    /**
     * Constructor
     *
     * @param Config $config
     * @param SessionManagerInterface $session
     */
    public function __construct(
        Config $config,
        SessionManagerInterface $session
    ) {
        $this->config = $config;
        $this->session = $session;

    }

    /**
     * Retrieve assoc array of checkout configuration
     *
     * @return array
     */
    public function getConfig()
    {
        $storeId = $this->session->getStoreId();
        return [
            'payment' => [
                self::SkipCash_Express_Code => [
                    'isActive' => $this->config->isActive($storeId),
                    'title' => $this->config->getTitle(),
                    'place_order_button_text' => $this->config->getPlaceOrderButtonText($storeId),
                    'redirection_hint' => $this->config->getRedirectionHint($storeId),
                ]
            ]
        ];
    }
}
