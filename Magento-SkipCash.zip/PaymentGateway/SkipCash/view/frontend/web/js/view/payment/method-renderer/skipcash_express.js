/*browser:true*/
/*global define*/

define([
    "jquery",
    "Magento_Checkout/js/view/payment/default",
    "Magento_Checkout/js/model/payment/additional-validators",
    "Magento_Checkout/js/action/place-order",
    "Magento_Ui/js/model/messages",
    "Magento_Checkout/js/action/redirect-on-success",
    "Magento_Checkout/js/model/full-screen-loader",
    "mage/url",
], function (
    $,
    Component,
    additionalValidators,
    placeOrderAction,
    messageContainer,
    redirectOnSuccessAction,
    fullScreenLoader,
    url
) {
    "use strict";

    return Component.extend({
        self: this,
        defaults: {
            template: "PaymentGateway_SkipCash/payment/skipcash_express_form",
        },
        messageContainer: messageContainer,
        context: function () {
            return this;
        },
        initialize: function () {
            this._super();
        },
        isActive: function () {
            return true;
        },
        getCode: function () {
            return "skipcash_express";
        },
        getTitle: function () {
            return window.checkoutConfig.payment[this.getCode()].title;
        },
        getPlaceOrderButtonText: function () {
            return window.checkoutConfig.payment[this.getCode()]
                .place_order_button_text;
        },
        getRedirectionHint: function () {
            return window.checkoutConfig.payment[this.getCode()]
                .redirection_hint;
        },
        afterPlaceOrder: function (orderid) {
            var self = this;
            $.ajax({
                type: "POST",
                data: {
                    orderId: orderid,
                },
                url: url.build("skipcash/checkout/placeorderredirect"),
                dataType: "json",
                showLoader: true,
                success: function (response) {
                    if (response.success) {
                        window.location.replace(response.payment_url);
                    } else if (response.success == false) {
                        $("body").trigger("processStop");
                        if (response.message) {
                            self.messageContainer.addErrorMessage({
                                message: JSON.stringify(response.message),
                            });
                        }
                        self.isPlaceOrderActionAllowed(true);
                    } else {
                        $("body").trigger("processStop");
                        self.messageContainer.addErrorMessage({
                            message: JSON.stringify(response.message),
                        });
                        self.isPlaceOrderActionAllowed(true);
                    }
                },
                error: function (err) {
                    self.messageContainer.addErrorMessage({
                        message:
                            "An error occurred on the server. Please try to place the order again.",
                    });
                    self.isPlaceOrderActionAllowed(true);
                },
            });
        },
        placeOrderSkipCash: function () {
            var self = this;

            self.isPlaceOrderActionAllowed(false);
            $("body").trigger("processStart");

            $.ajax({
                type: "POST",
                data: {
                    form_key: $.cookie("form_key"),
                    payment: true,
                },
                url: url.build("skipcash/checkout/placeordervalidation"),
                dataType: "json",
                showLoader: true,
                success: function (response) {
                    if (response.success) {
                        self.realPlaceOrder();
                    } else {
                        $("body").trigger("processStop");
                        self.messageContainer.addErrorMessage({
                            message: JSON.stringify(response.message),
                        });
                        self.isPlaceOrderActionAllowed(true);
                    }
                },
                error: function (err) {
                    self.messageContainer.addErrorMessage({
                        message:
                            "An error occurred on the server. Please try to place the order again.",
                    });
                    self.isPlaceOrderActionAllowed(true);
                },
            });
        },
        realPlaceOrder: function () {
            var self = this;
            var placeOrder;
            self.isPlaceOrderActionAllowed(false);
            placeOrder = placeOrderAction(
                this.getData(),
                false,
                this.messageContainer
            );
            $.when(placeOrder)
                .fail(function () {
                    self.isPlaceOrderActionAllowed(true);
                })
                .done(self.afterPlaceOrder.bind(this));
        },

        placeOrder: function (data, event) {
            var self = this;
            if (event) {
                event.preventDefault();
            }
            if (additionalValidators.validate()) {
                return self.placeOrderSkipCash();
            }
            return false;
        },
    });
});
